from kmertools.kclass import *
from kmertools.kmethods import *
from kmertools.parallel_process_variants import parallel_VCF_read
from kmertools.constants import *
from kmertools.encode_decode import *

